Traffic MARL SUMO + PettingZoo Skeleton

Folders:
- sumo : simulation configs
- env : PettingZoo environment
- agents : RL models and training
- utils : metrics and helpers

To run:
1. Install SUMO
2. pip install pettingzoo torch traci
3. python agents/train.py
