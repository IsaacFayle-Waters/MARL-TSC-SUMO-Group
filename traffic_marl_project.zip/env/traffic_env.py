from pettingzoo import ParallelEnv
import traci
import numpy as np

class TrafficEnv(ParallelEnv):

    metadata = {"name": "traffic_marl_env"}

    def __init__(self):
        self.agents = [f"agent_{i}" for i in range(9)]

    def reset(self, seed=None, options=None):
        traci.start(["sumo", "-c", "sumo/config.sumocfg"])
        observations = {agent: self._get_obs(agent) for agent in self.agents}
        return observations

    def step(self, actions):

        for agent, action in actions.items():
            self._apply_action(agent, action)

        traci.simulationStep()

        observations = {}
        rewards = {}
        terminations = {}
        truncations = {}
        infos = {}

        for agent in self.agents:
            observations[agent] = self._get_obs(agent)
            rewards[agent] = self._compute_reward(agent)
            terminations[agent] = False
            truncations[agent] = False
            infos[agent] = {}

        return observations, rewards, terminations, truncations, infos

    def _get_obs(self, agent):
        return np.zeros(6)

    def _apply_action(self, agent, action):
        pass

    def _compute_reward(self, agent):
        return 0.0
